Exo 2 Variable Font
===================

This download contains Exo 2 as both variable fonts and static fonts.

Exo 2 is a variable font with this axis:
  wght

This means all the styles are contained in these files:
  Exo_2/Exo2-VariableFont_wght.ttf
  Exo_2/Exo2-Italic-VariableFont_wght.ttf

If your app fully supports variable fonts, you can now pick intermediate styles
that aren’t available as static fonts. Not all apps support variable fonts, and
in those cases you can use the static font files for Exo 2:
  Exo_2/static/Exo2-Thin.ttf
  Exo_2/static/Exo2-ExtraLight.ttf
  Exo_2/static/Exo2-Light.ttf
  Exo_2/static/Exo2-Regular.ttf
  Exo_2/static/Exo2-Medium.ttf
  Exo_2/static/Exo2-SemiBold.ttf
  Exo_2/static/Exo2-Bold.ttf
  Exo_2/static/Exo2-ExtraBold.ttf
  Exo_2/static/Exo2-Black.ttf
  Exo_2/static/Exo2-ThinItalic.ttf
  Exo_2/static/Exo2-ExtraLightItalic.ttf
  Exo_2/static/Exo2-LightItalic.ttf
  Exo_2/static/Exo2-Italic.ttf
  Exo_2/static/Exo2-MediumItalic.ttf
  Exo_2/static/Exo2-SemiBoldItalic.ttf
  Exo_2/static/Exo2-BoldItalic.ttf
  Exo_2/static/Exo2-ExtraBoldItalic.ttf
  Exo_2/static/Exo2-BlackItalic.ttf

Get started
-----------

1. Install the font files you want to use

2. Use your app's font picker to view the font family and all the
available styles

Learn more about variable fonts
-------------------------------

  https://developers.google.com/web/fundamentals/design-and-ux/typography/variable-fonts
  https://variablefonts.typenetwork.com
  https://medium.com/variable-fonts

In desktop apps

  https://theblog.adobe.com/can-variable-fonts-illustrator-cc
  https://helpx.adobe.com/nz/photoshop/using/fonts.html#variable_fonts

Online

  https://developers.google.com/fonts/docs/getting_started
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Fonts/Variable_Fonts_Guide
  https://developer.microsoft.com/en-us/microsoft-edge/testdrive/demos/variable-fonts

Installing fonts

  MacOS: https://support.apple.com/en-us/HT201749
  Linux: https://www.google.com/search?q=how+to+install+a+font+on+gnu%2Blinux
  Windows: https://support.microsoft.com/en-us/help/314960/how-to-install-or-remove-a-font-in-windows

Android Apps

  https://developers.google.com/fonts/docs/android
  https://developer.android.com/guide/topics/ui/look-and-feel/downloadable-fonts

License
-------
Please read the full license text (OFL.txt) to understand the permissions,
restrictions and requirements for usage, redistribution, and modification.

You can use them in your products & projects – print or digital,
commercial or otherwise.

This isn't legal advice, please consider consulting a lawyer and see the full
license for all details.
